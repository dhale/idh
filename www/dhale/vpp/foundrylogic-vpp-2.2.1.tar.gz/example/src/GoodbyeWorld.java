public class GoodbyeWorld {
	public static void main(String[] args) {
		System.out.println("${project.getProperty("goodbyeWorldMessage")}");
	}
}
