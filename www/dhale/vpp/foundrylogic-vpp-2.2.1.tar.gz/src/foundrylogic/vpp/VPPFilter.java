/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp;

import org.apache.tools.ant.filters.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.types.*;
import org.apache.velocity.*;
import org.apache.velocity.app.*;

import java.io.*;

/**
 * Implementation of <b><a href="http://ant.apache.org">Ant</a></b>'s
 * <code>{@link org.apache.tools.ant.filters.ChainableReader}</code> that
 * supports cpp-like preprocessing using
 * </b><a href="http://jakarta.apache.org/velocity">Velocity</a></b>.
 * <p>
 * <b><code>VPPFilter</code></b> provides access to <b>Ant's</b> project
 * properties through a single property called <code>ant</code>.  For example,
 * <code>$ant.foobar</code> will return the value of the current <b>Ant</b>
 * project's property <code>foobar</code>.
 * <p>
 * The following target demonstrates the use of VPPFilter:
 * <pre>
 *   &lt;target name="vppfilter" depends="defineTasks"&gt;
 *       &lt;copy todir="output" overwrite="true"&gt;
 *           &lt;fileset dir="src"&gt;
 *               &lt;include name="**&#047;*.html.vpp"/&gt;
 *           &lt;/fileset&gt;
 *           &lt;filterchain&gt;
 *               &lt;filterreader classname="foundrylogic.vpp.VPPFilter"&gt;
 *                   &lt;classpath refid="vppPath"/&gt;
 *               &lt;/filterreader&gt;
 *           &lt;/filterchain&gt;
 *           &lt;mapper type="glob" from="*.html.vpp" to="*.html"/&gt;
 *       &lt;/copy&gt;
 *   &lt;/target&gt;
 * </pre>
 *
 * Note that if you are defining a <code>copy</code> task that performs no other
 * than <code>VPPFilter</code>, you can use {@link VPPCopy} instead.

 * @see foundrylogic.vpp.VPPCopy
 * @see foundrylogic.vpp.VPPJavac
 *
 * @author <a href="mailto:didge@foundrylogic.com">didge</a>
 *
 * @version $Revision: 1.7.2.6 $
 */

public class VPPFilter extends BaseParamFilterReader implements ChainableReader {
    private VPPConfig vppConfig;
    private boolean preprocessed;

    public VPPFilter() {
        super();
    }

    public VPPFilter(final Reader in) {
        super(in);
    }

    protected VPPFilter(final Reader in, VPPConfig vppConfig) {
        this(in);
        this.vppConfig = vppConfig;
        setInitialized(true);
    }

    public boolean getPreprocessed() {
        return preprocessed;
    }

    public void setPreprocessed(boolean preprocessed) {
        this.preprocessed = preprocessed;
    }


    public Reader chain(Reader rdr) {
        return new VPPFilter(rdr, vppConfig);
    }

    public int read() throws IOException {
        if(!getInitialized()) initialize();
        if(!getPreprocessed()) preprocess();

        return super.read();
    }

    public boolean ready() throws IOException {
        if(!getInitialized()) initialize();
        if(!getPreprocessed()) preprocess();

        return super.ready();
    }

    public int read(char cbuf[]) throws IOException {
        if(!getInitialized()) initialize();
        if(!getPreprocessed()) preprocess();

        return super.read(cbuf);
    }

    protected void initialize() {
        if(vppConfig == null) {
            Parameter[] parameters = getParameters();
            if(parameters != null) {
                for(int i = 0; i < parameters.length; i++) {
                    Parameter parameter = parameters[i];
                    if(parameter.getType().equals("config") && parameter.getName().equals("refid")) {
                        Object obj = getProject().getReference(parameter.getValue());
                        if(obj != null && obj instanceof VPPConfig) {
                            vppConfig = (VPPConfig)obj;
                        }
                    }
                    else {
                        throw new BuildException("unknown parameter type '" + parameter.getType() + "' or name '" + parameter.getName() + "'");
                    }
                }
            }
            if(vppConfig == null) {
                vppConfig = VPPConfig.getDefaultConfig(getProject());
            }
        }

        setInitialized(true);
    }

    protected void preprocess() throws IOException {
        try {
            VelocityEngine velocityEngine = vppConfig.getVelocityEngine();
            String inputEncoding = (String)velocityEngine.getProperty(VelocityEngine.INPUT_ENCODING);
            File prepFile = null;
            Writer prepWriter = null;
            boolean useTempFile = vppConfig.isUseTempFile();
            if(useTempFile) {
                File tempDir = vppConfig.getTempDir();
                if(tempDir.exists() == false) {
                    tempDir.mkdirs();
                }
                prepFile = vppConfig.getFileUtils().createTempFile("out", "vpp", tempDir);

                prepWriter = new OutputStreamWriter(new FileOutputStream(prepFile), inputEncoding);
            }
            else {
                // No output encoding needed with StringWriter
                prepWriter = new StringWriter();
            }

            try {
                // The childContext prevents cross contamination between calls to preprocess()
                VelocityContext childContext = new VelocityContext(vppConfig.getVelocityContext());
                vppConfig.getVelocityEngine().evaluate(childContext, prepWriter, "vpp", in);
            }
            finally {
                prepWriter.close();
            }

            if(useTempFile) {
                in = new InputStreamReader(new FileInputStream(prepFile), inputEncoding);
            }
            else {
                String prepText = prepWriter.toString();
                in = new StringReader(prepText);
            }

            setPreprocessed(true);
        }
        catch(Exception exc) {
            VPPCopyTool vpp = (VPPCopyTool)this.vppConfig.getVelocityContext().get("vpp");
            String filename = "<stream>";
            if(vpp != null) {
                filename = vpp.getSourceName();
            }
            BuildException exc2 = new BuildException("error in '" + filename + "': " + exc.getMessage());
            exc2.setStackTrace(exc.getStackTrace());

            throw exc2;
        }
    }

    public void addConfiguredConfig(VPPConfig vppConfig) {
        this.vppConfig = vppConfig;
    }

    public VPPConfig getConfig() {
        return this.vppConfig;
    }
}
