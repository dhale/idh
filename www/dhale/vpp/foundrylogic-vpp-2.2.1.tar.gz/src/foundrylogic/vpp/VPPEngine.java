/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp;

import foundrylogic.vpp.log.*;
import org.apache.tools.ant.types.*;
import org.apache.tools.ant.*;
import org.apache.velocity.app.*;
import org.apache.velocity.runtime.log.*;

import java.util.*;

public class VPPEngine extends DataType {
    private VelocityEngine velocityEngine;
    private List configurerList;
    private boolean useVelocityLogger;

    public VPPEngine() {
        configurerList = new ArrayList();
        useVelocityLogger = false;
    }

    public VelocityEngine getVelocityEngine() {
        if(velocityEngine == null) {
            velocityEngine = new VelocityEngine();

            try {
                defaultInit(velocityEngine);
                Project project = getProject();
                for(Iterator configurers = configurerList.iterator(); configurers.hasNext();) {
                    Configurer configurer = (Configurer)configurers.next();
                    configurer.configure(velocityEngine, project);
                }

                velocityEngine.init();
            }
            catch(Exception e) {
                throw new BuildException("could not initialize the VelocityEngine", e);
            }
        }
        return velocityEngine;
    }

    protected void defaultInit(VelocityEngine velocityEngine) {

        Project project = getProject();

        if(useVelocityLogger == false) {
            Task owningTask = project.getThreadTask(Thread.currentThread());
            LogSystem antLogAdapter = null;
            if(owningTask != null) {
                antLogAdapter= new VPPTaskLogAdapter(owningTask);
            }
            else {
                antLogAdapter= new VPPProjectLogAdapter(project);
            }
            velocityEngine.setProperty(VelocityEngine.RUNTIME_LOG_LOGSYSTEM, antLogAdapter);
        }
        // Make the FileResourceLoader load relative to the Project basedir rather than ".".
        velocityEngine.setProperty(VelocityEngine.FILE_RESOURCE_LOADER_PATH,
                project.getBaseDir().getAbsolutePath());
        // Avoid error message indicating VM_global_library.vm cannot be loaded
        velocityEngine.setProperty(VelocityEngine.VM_LIBRARY, "");
    }

    public void setUseVelocityLogger(boolean useVelocityLogger) {
        this.useVelocityLogger = useVelocityLogger;
    }

    public void addConfiguredProperty(VPPEngineProperty property) {
        configurerList.add(property);
    }

    /**
     * This interface supports the deferred configuration of properties
     * until after the Velocity Engine is initialized.
     */
    public interface Configurer {
        public void configure(VelocityEngine velocityEngine, Project project);
    }
}
