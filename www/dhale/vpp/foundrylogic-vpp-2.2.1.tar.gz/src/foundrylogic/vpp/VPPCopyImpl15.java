/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp;

import org.apache.tools.ant.*;
import org.apache.tools.ant.util.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import org.apache.velocity.*;

import java.util.*;
import java.io.*;
import java.lang.reflect.*;

/**
 * Implements VPPCopy for Ant 1.5x API.
 *
 * @see foundrylogic.vpp.VPPCopy
 * @see foundrylogic.vpp.VPPCopyImpl
 * @see foundrylogic.vpp.VPPCopyImpl16
 *
 * @author <a href="mailto:didge@foundrylogic.com">didge</a>
 *
 * @version $Revision: 1.1.2.2 $
 */
public class VPPCopyImpl15 implements VPPCopyImpl {
    protected String[] _toFiles = new String[1];

    public String[] getToFiles(String fromFile, Hashtable fileCopyMap) {
        _toFiles[0] = (String)fileCopyMap.get(fromFile);
        return _toFiles;
    }

    public void copyFile(FileUtils fileUtils, File srcFile, File dstFile, FilterSetCollection executionFilters, Vector filterChain, boolean overwrite, boolean preserveLastModified, String inputEncoding, String outputEncoding, Project project) throws IOException {
        fileUtils.copyFile(srcFile, dstFile, executionFilters, filterChain, overwrite, preserveLastModified, inputEncoding, project);
    }

    public String getOutputEncoding(VPPCopy copy) {
        return copy.getEncoding();
    }

    public void handleEmptyDirectories(VPPCopy copy, boolean includeEmpty, Hashtable dirCopyMap, File destDir) {
        if (includeEmpty) {
            Enumeration e = dirCopyMap.elements();
            int count = 0;
            while (e.hasMoreElements()) {
                File d = new File((String) e.nextElement());
                if (!d.exists()) {
                    if (!d.mkdirs()) {
                        copy.log("Unable to create directory "
                            + d.getAbsolutePath(), Project.MSG_ERR);
                    } else {
                        count++;
                    }
                }
            }

            if (count > 0) {
                copy.log("Copied " + count +
                    " empty director" +
                    (count == 1 ? "y" : "ies") +
                    " to " + destDir.getAbsolutePath());
            }
        }
    }
}
