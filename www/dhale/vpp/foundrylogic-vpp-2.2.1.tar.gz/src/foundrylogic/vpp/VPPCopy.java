/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp;

import org.apache.tools.ant.*;
import org.apache.tools.ant.util.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import org.apache.velocity.*;

import java.util.*;
import java.io.*;

/**
 * Extends <b><a href="http://jakarta.apache.org/ant">Ant</a></b>'s
 * <code>{@link org.apache.tools.ant.taskdefs.Copy}</code> task with integrated
 * cpp-like preprocessing using {@link VPPFilter}.
 * <p>
 * This task is a 'drop in' replacement for <code>Copy</code> and may be used
 * anywhere <code>Copy</code> is used.
 * <p>Example usage:
 * <pre>
 *    &lt;target name="vppcopy" &gt;
 *       &lt;vppcopy todir="output" overwrite="true"&gt;
 *           &lt;fileset dir="src" includes="**&#047;*.html.vpp"/&gt;
 *           &lt;mapper type="glob" from="*.html.vpp" to="*.html"/&gt;
 *       &lt;/vppcopy&gt;
 *   &lt;/target&gt;
 * </pre>
 *
 * @see foundrylogic.vpp.VPPFilter
 * @see foundrylogic.vpp.VPPJavac
 *
 * @author <a href="mailto:didge@foundrylogic.com">didge</a>
 *
 * @version $Revision: 1.2.2.8 $
 */
public class VPPCopy extends Copy {
    protected static VPPCopyImpl _vppCopyImpl;

    protected VPPFilter _vppFilter;

    static {
        Properties props = new Properties();
        InputStream in =
                VPPCopy.class.getResourceAsStream("/org/apache/tools/ant/version.txt");
        try {
            props.load(in);
            in.close();
        }
        catch(IOException e) {
            throw new BuildException("could not load ant version information", e);
        }

        String version = props.getProperty("VERSION");
        if(version.compareTo("1.6") > -1) {
            try {
                _vppCopyImpl = (VPPCopyImpl)Class.forName("foundrylogic.vpp.VPPCopyImpl16").newInstance();
            }
            catch(Exception e) {
                throw new BuildException("could not load class 'foundrylogic.vpp.VPPCopyImpl16'");
            }
        }
        else if(version.compareTo("1.5") > -1) {
            try {
                _vppCopyImpl = (VPPCopyImpl)Class.forName("foundrylogic.vpp.VPPCopyImpl15").newInstance();
            }
            catch(Exception e) {
                throw new BuildException("could not load class 'foundrylogic.vpp.VPPCopyImpl15'");
            }
        }
        else {
            throw new BuildException("vpp does not support ant version '" + version + "'");
        }
    }

    public VPPCopy() {
        _vppFilter = new VPPFilter();
        FilterChain filterChain = createFilterChain();
        filterChain.getFilterReaders().add(_vppFilter);
    }

    public void addConfiguredConfig(VPPConfig vppConfig) {
        _vppFilter.addConfiguredConfig(vppConfig);
    }

    public void execute() throws BuildException {
        _vppFilter.setProject(getProject());
        _vppFilter.initialize();
        super.execute();
    }

    protected void doFileOperations() {
        if(fileCopyMap.size() > 0) {
            log("Copying " + fileCopyMap.size()
                    + " file" + (fileCopyMap.size() == 1 ? "" : "s")
                    + " to " + destDir.getAbsolutePath());
            VPPConfig vppConfig = _vppFilter.getConfig();
            VelocityContext velocityContext = vppConfig.getVelocityContext();

            Enumeration e = fileCopyMap.keys();

            Vector filterChains = getFilterChains();
            String inputEncoding = getEncoding();
            String outputEncoding = _vppCopyImpl.getOutputEncoding(this);
            FileUtils fileUtils = getFileUtils();
            Project project = getProject();

            while (e.hasMoreElements()) {
                String fromFile = (String)e.nextElement();
                String[] toFiles = _vppCopyImpl.getToFiles(fromFile, fileCopyMap);

                for(int i = 0; i < toFiles.length; i++) {
                    String toFile = toFiles[i];

                    if(fromFile.equals(toFile)) {
                        log("Skipping self-copy of " + fromFile, verbosity);
                        continue;
                    }

                    try {
                        log("Copying " + fromFile + " to " + toFile, verbosity);

                        FilterSetCollection executionFilters =
                                new FilterSetCollection();
                        if(filtering) {
                            executionFilters
                                    .addFilterSet(getProject().getGlobalFilterSet());
                        }
                        for(Enumeration filterEnum = getFilterSets().elements();
                            filterEnum.hasMoreElements();) {
                            executionFilters
                                    .addFilterSet((FilterSet)filterEnum.nextElement());
                        }

                        File srcFile = new File(fromFile);
                        File dstFile = new File(toFile);
                        velocityContext.put("vpp", new VPPCopyTool(srcFile, dstFile, inputEncoding, outputEncoding));

                        _vppCopyImpl.copyFile(fileUtils, srcFile, dstFile, executionFilters, filterChains, forceOverwrite, preserveLastModified, inputEncoding, outputEncoding, project);


                    }
                    catch(Exception ioe) {
                        String msg = "Failed to copy " + fromFile + " to " + toFile
                                + " due to " + ioe.getMessage();
                        File targetFile = new File(toFile);
                        if(targetFile.exists() && !targetFile.delete()) {
                            msg += " and I couldn't delete the corrupt " + toFile;
                        }
                        throw new BuildException(msg, ioe, getLocation());
                    }
                }
            }
        }

    }
}
