/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp.log;

import org.apache.velocity.runtime.log.LogSystem;
import org.apache.velocity.runtime.RuntimeServices;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.tools.ant.Project;

/**
 * <p>Support for adapting Velocity's LogSystem to Ant's log methods.
 * Velocity log levels are mapped to corresponding log levels defined
 * in Ant's logging API.  The end result is messages will only be output
 * if the Ant log level is high enough.</p>
 *
 * @see       org.apache.velocity.runtime.log.LogSystem
 * @author    <a href="mailto:billb@progress.com">Bill Burton</a>
 * @author    <a href="mailto:didge@foundrylogic.com">didge</a>
 * @version   $Id: VPPLogAdapterSupport.java,v 1.1.2.1 2003/02/10 17:06:27 didge Exp $
 */
public abstract class VPPLogAdapterSupport implements LogSystem {

    /**
     */
    public void init(RuntimeServices rs) throws Exception {
    }

    /**
     * <p>Log Velocity messages through the Ant's log method on the Project or Task
     * classes.  If this class is instantiated with a Task object instance, logging
     * will be through the Task's log method.  Otherwise, logging will be performed
     * through the Project's log method.
     *
     * <p>The mapping of logging levels from Velocity to Ant is as follows:
     * </p>
     *
     * <blockquote><pre>
     * Velocity Level      --&gt;  Ant Level
     * LogSystem.DEBUG_ID  --&gt;  Project.MSG_DEBUG
     * LogSystem.INFO_ID   --&gt;  Project.MSG_VERBOSE
     * LogSystem.WARN_ID   --&gt;  Project.MSG_WARN
     * LogSystem.ERROR_ID  --&gt;  Project.MSG_ERR
     * </pre></blockquote>
     *
     * @param level    severity level
     * @param message  complete error message
     * @see   org.apache.velocity.runtime.log.LogSystem
     * @see   org.apache.tools.ant.Task#log(java.lang.String, int)
     * @see   org.apache.tools.ant.Project#log(java.lang.String, int)
     */
    public void logVelocityMessage(int level, String message) {
        switch(level) {
            case LogSystem.WARN_ID:
                log(RuntimeConstants.WARN_PREFIX + message, Project.MSG_WARN);
                break;
            case LogSystem.INFO_ID:
                log(RuntimeConstants.INFO_PREFIX + message, Project.MSG_VERBOSE);
                break;
            case LogSystem.DEBUG_ID:
                log(RuntimeConstants.DEBUG_PREFIX + message, Project.MSG_DEBUG);
                break;
            case LogSystem.ERROR_ID:
                log(RuntimeConstants.ERROR_PREFIX + message, Project.MSG_ERR);
                break;
            default:
                log(message);
                break;
        }
    }

    protected abstract void log(String message);

    protected abstract void log(String message, int level);
}
