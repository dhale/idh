/*
Copyright (c) 2003, FoundryLogic, LLC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

 * Neither the name of FoundryLogic, LLC nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).
*/

package foundrylogic.vpp;

import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import org.apache.tools.ant.types.selectors.*;

import java.io.*;

import foundrylogic.vpp.*;

/**
 * Extends <b><a href="http://jakarta.apache.org/ant">Ant</a></b>'s
 * <code>{@link org.apache.tools.ant.taskdefs.Javac}</code> task with integrated
 * cpp-like preprocessing using {@link VPPFilter}.
 * <p>
 * This task is a 'drop in' replacement for <code>Javac</code> and may be used
 * anywhere <code>Javac</code> is used.  This implementation adds only a few
 * additional parameters used to specify the preprocessing behavior:
 * <ul>
 * <li>{@link #setPreprocess}
 * <li>{@link #setPrepdir}
 * </ul>
 * Example usage:
 * <pre>
 *   &lt;target name="vppjavac" &gt;
 *      &lt;vppjavac preprocess="true" keep="true" destdir="classes" srcdir="src"&gt;
 *          &lt;classpath refid="myClassPath" /&gt;
 *      &lt;/vppjavac&gt;
 *  &lt;/target&gt;
 * </pre>
 *
 * @see foundrylogic.vpp.VPPCopy
 * @see foundrylogic.vpp.VPPJavac
 *
 * @author <a href="mailto:didge@foundrylogic.com">didge</a>
 *
 * @version $Revision: 1.7.2.7 $
 */
public class VPPJavac extends Javac {

    private boolean preprocess = true;
    private boolean keep = true;
    private File prepdir;
    private VPPCopy vppCopy;

    /**
     * @return if false, no preprocessing will be performed; the
     * default is <code>true</code>
     */
    public boolean getPreprocess() {
        return preprocess;
    }

    /**
     * Sets the preprocess switch.
     * @param preprocess if false, no preprocessing will be performed; the
     * default is <code>true</code>
     */
    public void setPreprocess(boolean preprocess) {
        this.preprocess = preprocess;
    }

    /**
     * @return if true, any temporary preprocessing files will be kept; the
     * default is <code>false</code>
     */
    public boolean getKeep() {
        return keep;
    }

    /**
     * Sets the keep switch.
     * @param keep if true, any temporary preprocessing files will be kept; the
     * default is <code>false</code>
     */
    public void setKeep(boolean keep) {
        this.keep = keep;
    }


    public File getPrepdir() {
        return prepdir;
    }

    public void setPrepdir(File prepdir) {
        this.prepdir = prepdir;
    }

    public void execute() throws BuildException {
        if(!getPreprocess()) {
            super.execute();
            return;
        }

        // This section is straight from Javac.execute().
        Path src = getSrcdir();  // src is private in super...
        if(src == null) {
            throw new BuildException("srcdir attribute must be set!", getLocation());
        }
        String[] list = src.list();
        if(list.length == 0) {
            throw new BuildException("srcdir attribute must be set!", getLocation());
        }

        File destdir = getDestdir(); // destDir is private in super...
        if(destdir != null && !destdir.isDirectory()) {
            throw new BuildException("destination directory '" + destdir + "' does not exist or is not a directory", getLocation());
        }

        preprocess();
        recreateSrc();
        setSrcdir(new Path(getProject(), prepdir.getAbsolutePath()));
        super.execute();
        if(keep == false) {
            deletePrepdir();
        }
    }

    private void preprocess() {
        preparePrepdir();

        vppCopy.init();
        FileSelector[] fileSelectors = getSelectors(getProject());

        String[] srcPaths = getSrcdir().list();
        for(int i = 0; i < srcPaths.length; i++) {
            String srcPath = srcPaths[i];
            FileSet fileSet = new FileSet();
            fileSet.setDir(new File(srcPath));
            vppCopy.addFileset(fileSet);
            for(int j = 0; j < fileSelectors.length; j++) {
                FileSelector fileSelector = fileSelectors[j];
                fileSet.appendSelector(fileSelector);
            }
        }

        vppCopy.setTodir(prepdir);
        Mapper mapper = vppCopy.createMapper();
        mapper.setFrom("*.java");
        mapper.setTo("*.java");
        Mapper.MapperType mapperType = new Mapper.MapperType();
        mapperType.setValue("glob");
        mapper.setType(mapperType);

        // Preprocess!!
        vppCopy.execute();
    }

    protected void preparePrepdir() {
        if(prepdir == null) {
            String prepdirName = getProject().getBaseDir().getAbsolutePath() + File.separator + "vppjavac.out";
            prepdir = new File(prepdirName);
        }
        if(prepdir.exists() == false) {
            prepdir.mkdirs();
        }
        else {
            /*
                Would it make any sense to try to remove any old preprocessed files
                that no longer exist in the src fileset?  Thoughts:
                1. The same prepdir maybe used with different src filesets.
            */
        }
    }

    protected void deletePrepdir() {
        if(prepdir.exists() == true) {
            FileSet oldPrepFiles = new FileSet();
            oldPrepFiles.setDir(prepdir);
            PatternSet.NameEntry name = oldPrepFiles.createInclude();
            name.setName("**");
            Delete deleteTask = new Delete();
            deleteTask.setTaskName(getTaskName());
            deleteTask.setProject(getProject());
            deleteTask.setIncludeEmptyDirs(true);
            deleteTask.setFailOnError(false);
            deleteTask.setVerbose(false);
            deleteTask.addFileset(oldPrepFiles);
            deleteTask.execute();
        }
    }

    public void init() {
        if(vppCopy == null) {
            vppCopy = new VPPCopy();
            vppCopy.setProject(getProject());
            vppCopy.setTaskName(getTaskName());
            vppCopy.setLocation(getLocation());
        }
    }

    public void addConfiguredConfig(VPPConfig vppConfig) {
        vppCopy.addConfiguredConfig(vppConfig);
    }
}
